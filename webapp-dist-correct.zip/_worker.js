var Dt=Object.defineProperty;var We=e=>{throw TypeError(e)};var Ct=(e,t,r)=>t in e?Dt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var h=(e,t,r)=>Ct(e,typeof t!="symbol"?t+"":t,r),Fe=(e,t,r)=>t.has(e)||We("Cannot "+r);var o=(e,t,r)=>(Fe(e,t,"read from private field"),r?r.call(e):t.get(e)),v=(e,t,r)=>t.has(e)?We("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,r),f=(e,t,r,a)=>(Fe(e,t,"write to private field"),a?a.call(e,r):t.set(e,r),r),P=(e,t,r)=>(Fe(e,t,"access private method"),r);var Ye=(e,t,r,a)=>({set _(s){f(e,t,s,r)},get _(){return o(e,t,a)}});var Xe=(e,t,r)=>(a,s)=>{let n=-1;return i(0);async function i(d){if(d<=n)throw new Error("next() called multiple times");n=d;let c,l=!1,u;if(e[d]?(u=e[d][0][0],a.req.routeIndex=d):u=d===e.length&&s||void 0,u)try{c=await u(a,()=>i(d+1))}catch(m){if(m instanceof Error&&t)a.error=m,c=await t(m,a),l=!0;else throw m}else a.finalized===!1&&r&&(c=await r(a));return c&&(a.finalized===!1||l)&&(a.res=c),a}},Mt=Symbol(),It=async(e,t=Object.create(null))=>{const{all:r=!1,dot:a=!1}=t,n=(e instanceof pt?e.raw.headers:e.headers).get("Content-Type");return n!=null&&n.startsWith("multipart/form-data")||n!=null&&n.startsWith("application/x-www-form-urlencoded")?$t(e,{all:r,dot:a}):{}};async function $t(e,t){const r=await e.formData();return r?Ht(r,t):{}}function Ht(e,t){const r=Object.create(null);return e.forEach((a,s)=>{t.all||s.endsWith("[]")?Vt(r,s,a):r[s]=a}),t.dot&&Object.entries(r).forEach(([a,s])=>{a.includes(".")&&(Ft(r,a,s),delete r[a])}),r}var Vt=(e,t,r)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(r):e[t]=[e[t],r]:t.endsWith("[]")?e[t]=[r]:e[t]=r},Ft=(e,t,r)=>{let a=e;const s=t.split(".");s.forEach((n,i)=>{i===s.length-1?a[n]=r:((!a[n]||typeof a[n]!="object"||Array.isArray(a[n])||a[n]instanceof File)&&(a[n]=Object.create(null)),a=a[n])})},lt=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},Lt=e=>{const{groups:t,path:r}=Ut(e),a=lt(r);return Kt(a,t)},Ut=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(r,a)=>{const s=`@${a}`;return t.push([s,r]),s}),{groups:t,path:e}},Kt=(e,t)=>{for(let r=t.length-1;r>=0;r--){const[a]=t[r];for(let s=e.length-1;s>=0;s--)if(e[s].includes(a)){e[s]=e[s].replace(a,t[r][1]);break}}return e},Te={},Bt=(e,t)=>{if(e==="*")return"*";const r=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(r){const a=`${e}#${t}`;return Te[a]||(r[2]?Te[a]=t&&t[0]!==":"&&t[0]!=="*"?[a,r[1],new RegExp(`^${r[2]}(?=/${t})`)]:[e,r[1],new RegExp(`^${r[2]}$`)]:Te[a]=[e,r[1],!0]),Te[a]}return null},Be=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,r=>{try{return t(r)}catch{return r}})}},Gt=e=>Be(e,decodeURI),ct=e=>{const t=e.url,r=t.indexOf("/",t.indexOf(":")+4);let a=r;for(;a<t.length;a++){const s=t.charCodeAt(a);if(s===37){const n=t.indexOf("?",a),i=t.slice(r,n===-1?void 0:n);return Gt(i.includes("%25")?i.replace(/%25/g,"%2525"):i)}else if(s===63)break}return t.slice(r,a)},zt=e=>{const t=ct(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},le=(e,t,...r)=>(r.length&&(t=le(t,...r)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),dt=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),r=[];let a="";return t.forEach(s=>{if(s!==""&&!/\:/.test(s))a+="/"+s;else if(/\:/.test(s))if(/\?/.test(s)){r.length===0&&a===""?r.push("/"):r.push(a);const n=s.replace("?","");a+="/"+n,r.push(a)}else a+="/"+s}),r.filter((s,n,i)=>i.indexOf(s)===n)},Le=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?Be(e,mt):e):e,ut=(e,t,r)=>{let a;if(!r&&t&&!/[%+]/.test(t)){let i=e.indexOf("?",8);if(i===-1)return;for(e.startsWith(t,i+1)||(i=e.indexOf(`&${t}`,i+1));i!==-1;){const d=e.charCodeAt(i+t.length+1);if(d===61){const c=i+t.length+2,l=e.indexOf("&",c);return Le(e.slice(c,l===-1?void 0:l))}else if(d==38||isNaN(d))return"";i=e.indexOf(`&${t}`,i+1)}if(a=/[%+]/.test(e),!a)return}const s={};a??(a=/[%+]/.test(e));let n=e.indexOf("?",8);for(;n!==-1;){const i=e.indexOf("&",n+1);let d=e.indexOf("=",n);d>i&&i!==-1&&(d=-1);let c=e.slice(n+1,d===-1?i===-1?void 0:i:d);if(a&&(c=Le(c)),n=i,c==="")continue;let l;d===-1?l="":(l=e.slice(d+1,i===-1?void 0:i),a&&(l=Le(l))),r?(s[c]&&Array.isArray(s[c])||(s[c]=[]),s[c].push(l)):s[c]??(s[c]=l)}return t?s[t]:s},Jt=ut,Wt=(e,t)=>ut(e,t,!0),mt=decodeURIComponent,Qe=e=>Be(e,mt),ue,D,K,ft,ht,Ke,B,rt,pt=(rt=class{constructor(e,t="/",r=[[]]){v(this,K);h(this,"raw");v(this,ue);v(this,D);h(this,"routeIndex",0);h(this,"path");h(this,"bodyCache",{});v(this,B,e=>{const{bodyCache:t,raw:r}=this,a=t[e];if(a)return a;const s=Object.keys(t)[0];return s?t[s].then(n=>(s==="json"&&(n=JSON.stringify(n)),new Response(n)[e]())):t[e]=r[e]()});this.raw=e,this.path=t,f(this,D,r),f(this,ue,{})}param(e){return e?P(this,K,ft).call(this,e):P(this,K,ht).call(this)}query(e){return Jt(this.url,e)}queries(e){return Wt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((r,a)=>{t[a]=r}),t}async parseBody(e){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await It(this,e))}json(){return o(this,B).call(this,"text").then(e=>JSON.parse(e))}text(){return o(this,B).call(this,"text")}arrayBuffer(){return o(this,B).call(this,"arrayBuffer")}blob(){return o(this,B).call(this,"blob")}formData(){return o(this,B).call(this,"formData")}addValidatedData(e,t){o(this,ue)[e]=t}valid(e){return o(this,ue)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[Mt](){return o(this,D)}get matchedRoutes(){return o(this,D)[0].map(([[,e]])=>e)}get routePath(){return o(this,D)[0].map(([[,e]])=>e)[this.routeIndex].path}},ue=new WeakMap,D=new WeakMap,K=new WeakSet,ft=function(e){const t=o(this,D)[0][this.routeIndex][1][e],r=P(this,K,Ke).call(this,t);return r&&/\%/.test(r)?Qe(r):r},ht=function(){const e={},t=Object.keys(o(this,D)[0][this.routeIndex][1]);for(const r of t){const a=P(this,K,Ke).call(this,o(this,D)[0][this.routeIndex][1][r]);a!==void 0&&(e[r]=/\%/.test(a)?Qe(a):a)}return e},Ke=function(e){return o(this,D)[1]?o(this,D)[1][e]:e},B=new WeakMap,rt),Yt={Stringify:1},gt=async(e,t,r,a,s)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const n=e.callbacks;return n!=null&&n.length?(s?s[0]+=e:s=[e],Promise.all(n.map(d=>d({phase:t,buffer:s,context:a}))).then(d=>Promise.all(d.filter(Boolean).map(c=>gt(c,t,!1,a,s))).then(()=>s[0]))):Promise.resolve(e)},Xt="text/plain; charset=UTF-8",Ue=(e,t)=>({"Content-Type":e,...t}),ke,Pe,V,me,F,T,Ee,pe,fe,te,Re,qe,G,ce,st,Qt=(st=class{constructor(e,t){v(this,G);v(this,ke);v(this,Pe);h(this,"env",{});v(this,V);h(this,"finalized",!1);h(this,"error");v(this,me);v(this,F);v(this,T);v(this,Ee);v(this,pe);v(this,fe);v(this,te);v(this,Re);v(this,qe);h(this,"render",(...e)=>(o(this,pe)??f(this,pe,t=>this.html(t)),o(this,pe).call(this,...e)));h(this,"setLayout",e=>f(this,Ee,e));h(this,"getLayout",()=>o(this,Ee));h(this,"setRenderer",e=>{f(this,pe,e)});h(this,"header",(e,t,r)=>{this.finalized&&f(this,T,new Response(o(this,T).body,o(this,T)));const a=o(this,T)?o(this,T).headers:o(this,te)??f(this,te,new Headers);t===void 0?a.delete(e):r!=null&&r.append?a.append(e,t):a.set(e,t)});h(this,"status",e=>{f(this,me,e)});h(this,"set",(e,t)=>{o(this,V)??f(this,V,new Map),o(this,V).set(e,t)});h(this,"get",e=>o(this,V)?o(this,V).get(e):void 0);h(this,"newResponse",(...e)=>P(this,G,ce).call(this,...e));h(this,"body",(e,t,r)=>P(this,G,ce).call(this,e,t,r));h(this,"text",(e,t,r)=>!o(this,te)&&!o(this,me)&&!t&&!r&&!this.finalized?new Response(e):P(this,G,ce).call(this,e,t,Ue(Xt,r)));h(this,"json",(e,t,r)=>P(this,G,ce).call(this,JSON.stringify(e),t,Ue("application/json",r)));h(this,"html",(e,t,r)=>{const a=s=>P(this,G,ce).call(this,s,t,Ue("text/html; charset=UTF-8",r));return typeof e=="object"?gt(e,Yt.Stringify,!1,{}).then(a):a(e)});h(this,"redirect",(e,t)=>{const r=String(e);return this.header("Location",/[^\x00-\xFF]/.test(r)?encodeURI(r):r),this.newResponse(null,t??302)});h(this,"notFound",()=>(o(this,fe)??f(this,fe,()=>new Response),o(this,fe).call(this,this)));f(this,ke,e),t&&(f(this,F,t.executionCtx),this.env=t.env,f(this,fe,t.notFoundHandler),f(this,qe,t.path),f(this,Re,t.matchResult))}get req(){return o(this,Pe)??f(this,Pe,new pt(o(this,ke),o(this,qe),o(this,Re))),o(this,Pe)}get event(){if(o(this,F)&&"respondWith"in o(this,F))return o(this,F);throw Error("This context has no FetchEvent")}get executionCtx(){if(o(this,F))return o(this,F);throw Error("This context has no ExecutionContext")}get res(){return o(this,T)||f(this,T,new Response(null,{headers:o(this,te)??f(this,te,new Headers)}))}set res(e){if(o(this,T)&&e){e=new Response(e.body,e);for(const[t,r]of o(this,T).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const a=o(this,T).headers.getSetCookie();e.headers.delete("set-cookie");for(const s of a)e.headers.append("set-cookie",s)}else e.headers.set(t,r)}f(this,T,e),this.finalized=!0}get var(){return o(this,V)?Object.fromEntries(o(this,V)):{}}},ke=new WeakMap,Pe=new WeakMap,V=new WeakMap,me=new WeakMap,F=new WeakMap,T=new WeakMap,Ee=new WeakMap,pe=new WeakMap,fe=new WeakMap,te=new WeakMap,Re=new WeakMap,qe=new WeakMap,G=new WeakSet,ce=function(e,t,r){const a=o(this,T)?new Headers(o(this,T).headers):o(this,te)??new Headers;if(typeof t=="object"&&"headers"in t){const n=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[i,d]of n)i.toLowerCase()==="set-cookie"?a.append(i,d):a.set(i,d)}if(r)for(const[n,i]of Object.entries(r))if(typeof i=="string")a.set(n,i);else{a.delete(n);for(const d of i)a.append(n,d)}const s=typeof t=="number"?t:(t==null?void 0:t.status)??o(this,me);return new Response(e,{status:s,headers:a})},st),N="ALL",Zt="all",er=["get","post","put","delete","options","patch"],bt="Can not add a route since the matcher is already built.",yt=class extends Error{},tr="__COMPOSED_HANDLER",rr=e=>e.text("404 Not Found",404),Ze=(e,t)=>{if("getResponse"in e){const r=e.getResponse();return t.newResponse(r.body,r)}return console.error(e),t.text("Internal Server Error",500)},M,j,vt,I,Z,_e,Se,he,sr=(he=class{constructor(t={}){v(this,j);h(this,"get");h(this,"post");h(this,"put");h(this,"delete");h(this,"options");h(this,"patch");h(this,"all");h(this,"on");h(this,"use");h(this,"router");h(this,"getPath");h(this,"_basePath","/");v(this,M,"/");h(this,"routes",[]);v(this,I,rr);h(this,"errorHandler",Ze);h(this,"onError",t=>(this.errorHandler=t,this));h(this,"notFound",t=>(f(this,I,t),this));h(this,"fetch",(t,...r)=>P(this,j,Se).call(this,t,r[1],r[0],t.method));h(this,"request",(t,r,a,s)=>t instanceof Request?this.fetch(r?new Request(t,r):t,a,s):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${le("/",t)}`,r),a,s)));h(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(P(this,j,Se).call(this,t.request,t,void 0,t.request.method))})});[...er,Zt].forEach(n=>{this[n]=(i,...d)=>(typeof i=="string"?f(this,M,i):P(this,j,Z).call(this,n,o(this,M),i),d.forEach(c=>{P(this,j,Z).call(this,n,o(this,M),c)}),this)}),this.on=(n,i,...d)=>{for(const c of[i].flat()){f(this,M,c);for(const l of[n].flat())d.map(u=>{P(this,j,Z).call(this,l.toUpperCase(),o(this,M),u)})}return this},this.use=(n,...i)=>(typeof n=="string"?f(this,M,n):(f(this,M,"*"),i.unshift(n)),i.forEach(d=>{P(this,j,Z).call(this,N,o(this,M),d)}),this);const{strict:a,...s}=t;Object.assign(this,s),this.getPath=a??!0?t.getPath??ct:zt}route(t,r){const a=this.basePath(t);return r.routes.map(s=>{var i;let n;r.errorHandler===Ze?n=s.handler:(n=async(d,c)=>(await Xe([],r.errorHandler)(d,()=>s.handler(d,c))).res,n[tr]=s.handler),P(i=a,j,Z).call(i,s.method,s.path,n)}),this}basePath(t){const r=P(this,j,vt).call(this);return r._basePath=le(this._basePath,t),r}mount(t,r,a){let s,n;a&&(typeof a=="function"?n=a:(n=a.optionHandler,a.replaceRequest===!1?s=c=>c:s=a.replaceRequest));const i=n?c=>{const l=n(c);return Array.isArray(l)?l:[l]}:c=>{let l;try{l=c.executionCtx}catch{}return[c.env,l]};s||(s=(()=>{const c=le(this._basePath,t),l=c==="/"?0:c.length;return u=>{const m=new URL(u.url);return m.pathname=m.pathname.slice(l)||"/",new Request(m,u)}})());const d=async(c,l)=>{const u=await r(s(c.req.raw),...i(c));if(u)return u;await l()};return P(this,j,Z).call(this,N,le(t,"*"),d),this}},M=new WeakMap,j=new WeakSet,vt=function(){const t=new he({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,f(t,I,o(this,I)),t.routes=this.routes,t},I=new WeakMap,Z=function(t,r,a){t=t.toUpperCase(),r=le(this._basePath,r);const s={basePath:this._basePath,path:r,method:t,handler:a};this.router.add(t,r,[a,s]),this.routes.push(s)},_e=function(t,r){if(t instanceof Error)return this.errorHandler(t,r);throw t},Se=function(t,r,a,s){if(s==="HEAD")return(async()=>new Response(null,await P(this,j,Se).call(this,t,r,a,"GET")))();const n=this.getPath(t,{env:a}),i=this.router.match(s,n),d=new Qt(t,{path:n,matchResult:i,env:a,executionCtx:r,notFoundHandler:o(this,I)});if(i[0].length===1){let l;try{l=i[0][0][0][0](d,async()=>{d.res=await o(this,I).call(this,d)})}catch(u){return P(this,j,_e).call(this,u,d)}return l instanceof Promise?l.then(u=>u||(d.finalized?d.res:o(this,I).call(this,d))).catch(u=>P(this,j,_e).call(this,u,d)):l??o(this,I).call(this,d)}const c=Xe(i[0],this.errorHandler,o(this,I));return(async()=>{try{const l=await c(d);if(!l.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return l.res}catch(l){return P(this,j,_e).call(this,l,d)}})()},he),xt=[];function ar(e,t){const r=this.buildAllMatchers(),a=((s,n)=>{const i=r[s]||r[N],d=i[2][n];if(d)return d;const c=n.match(i[0]);if(!c)return[[],xt];const l=c.indexOf("",1);return[i[1][l],c]});return this.match=a,a(e,t)}var Ce="[^/]+",xe=".*",we="(?:|/.*)",de=Symbol(),nr=new Set(".\\+*[^]$()");function ir(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===xe||e===we?1:t===xe||t===we?-1:e===Ce?1:t===Ce?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var re,se,$,ie,or=(ie=class{constructor(){v(this,re);v(this,se);v(this,$,Object.create(null))}insert(t,r,a,s,n){if(t.length===0){if(o(this,re)!==void 0)throw de;if(n)return;f(this,re,r);return}const[i,...d]=t,c=i==="*"?d.length===0?["","",xe]:["","",Ce]:i==="/*"?["","",we]:i.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let l;if(c){const u=c[1];let m=c[2]||Ce;if(u&&c[2]&&(m===".*"||(m=m.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(m))))throw de;if(l=o(this,$)[m],!l){if(Object.keys(o(this,$)).some(p=>p!==xe&&p!==we))throw de;if(n)return;l=o(this,$)[m]=new ie,u!==""&&f(l,se,s.varIndex++)}!n&&u!==""&&a.push([u,o(l,se)])}else if(l=o(this,$)[i],!l){if(Object.keys(o(this,$)).some(u=>u.length>1&&u!==xe&&u!==we))throw de;if(n)return;l=o(this,$)[i]=new ie}l.insert(d,r,a,s,n)}buildRegExpStr(){const r=Object.keys(o(this,$)).sort(ir).map(a=>{const s=o(this,$)[a];return(typeof o(s,se)=="number"?`(${a})@${o(s,se)}`:nr.has(a)?`\\${a}`:a)+s.buildRegExpStr()});return typeof o(this,re)=="number"&&r.unshift(`#${o(this,re)}`),r.length===0?"":r.length===1?r[0]:"(?:"+r.join("|")+")"}},re=new WeakMap,se=new WeakMap,$=new WeakMap,ie),Me,Ne,at,lr=(at=class{constructor(){v(this,Me,{varIndex:0});v(this,Ne,new or)}insert(e,t,r){const a=[],s=[];for(let i=0;;){let d=!1;if(e=e.replace(/\{[^}]+\}/g,c=>{const l=`@\\${i}`;return s[i]=[l,c],i++,d=!0,l}),!d)break}const n=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let i=s.length-1;i>=0;i--){const[d]=s[i];for(let c=n.length-1;c>=0;c--)if(n[c].indexOf(d)!==-1){n[c]=n[c].replace(d,s[i][1]);break}}return o(this,Ne).insert(n,t,a,o(this,Me),r),a}buildRegExp(){let e=o(this,Ne).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const r=[],a=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(s,n,i)=>n!==void 0?(r[++t]=Number(n),"$()"):(i!==void 0&&(a[Number(i)]=++t),"")),[new RegExp(`^${e}`),r,a]}},Me=new WeakMap,Ne=new WeakMap,at),cr=[/^$/,[],Object.create(null)],De=Object.create(null);function wt(e){return De[e]??(De[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,r)=>r?`\\${r}`:"(?:|/.*)")}$`))}function dr(){De=Object.create(null)}function ur(e){var l;const t=new lr,r=[];if(e.length===0)return cr;const a=e.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,m],[p,w])=>u?1:p?-1:m.length-w.length),s=Object.create(null);for(let u=0,m=-1,p=a.length;u<p;u++){const[w,R,b]=a[u];w?s[R]=[b.map(([E])=>[E,Object.create(null)]),xt]:m++;let x;try{x=t.insert(R,m,w)}catch(E){throw E===de?new yt(R):E}w||(r[m]=b.map(([E,k])=>{const y=Object.create(null);for(k-=1;k>=0;k--){const[X,S]=x[k];y[X]=S}return[E,y]}))}const[n,i,d]=t.buildRegExp();for(let u=0,m=r.length;u<m;u++)for(let p=0,w=r[u].length;p<w;p++){const R=(l=r[u][p])==null?void 0:l[1];if(!R)continue;const b=Object.keys(R);for(let x=0,E=b.length;x<E;x++)R[b[x]]=d[R[b[x]]]}const c=[];for(const u in i)c[u]=r[i[u]];return[n,c,s]}function oe(e,t){if(e){for(const r of Object.keys(e).sort((a,s)=>s.length-a.length))if(wt(r).test(t))return[...e[r]]}}var z,J,Ie,kt,nt,mr=(nt=class{constructor(){v(this,Ie);h(this,"name","RegExpRouter");v(this,z);v(this,J);h(this,"match",ar);f(this,z,{[N]:Object.create(null)}),f(this,J,{[N]:Object.create(null)})}add(e,t,r){var d;const a=o(this,z),s=o(this,J);if(!a||!s)throw new Error(bt);a[e]||[a,s].forEach(c=>{c[e]=Object.create(null),Object.keys(c[N]).forEach(l=>{c[e][l]=[...c[N][l]]})}),t==="/*"&&(t="*");const n=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const c=wt(t);e===N?Object.keys(a).forEach(l=>{var u;(u=a[l])[t]||(u[t]=oe(a[l],t)||oe(a[N],t)||[])}):(d=a[e])[t]||(d[t]=oe(a[e],t)||oe(a[N],t)||[]),Object.keys(a).forEach(l=>{(e===N||e===l)&&Object.keys(a[l]).forEach(u=>{c.test(u)&&a[l][u].push([r,n])})}),Object.keys(s).forEach(l=>{(e===N||e===l)&&Object.keys(s[l]).forEach(u=>c.test(u)&&s[l][u].push([r,n]))});return}const i=dt(t)||[t];for(let c=0,l=i.length;c<l;c++){const u=i[c];Object.keys(s).forEach(m=>{var p;(e===N||e===m)&&((p=s[m])[u]||(p[u]=[...oe(a[m],u)||oe(a[N],u)||[]]),s[m][u].push([r,n-l+c+1]))})}}buildAllMatchers(){const e=Object.create(null);return Object.keys(o(this,J)).concat(Object.keys(o(this,z))).forEach(t=>{e[t]||(e[t]=P(this,Ie,kt).call(this,t))}),f(this,z,f(this,J,void 0)),dr(),e}},z=new WeakMap,J=new WeakMap,Ie=new WeakSet,kt=function(e){const t=[];let r=e===N;return[o(this,z),o(this,J)].forEach(a=>{const s=a[e]?Object.keys(a[e]).map(n=>[n,a[e][n]]):[];s.length!==0?(r||(r=!0),t.push(...s)):e!==N&&t.push(...Object.keys(a[N]).map(n=>[n,a[N][n]]))}),r?ur(t):null},nt),W,L,it,pr=(it=class{constructor(e){h(this,"name","SmartRouter");v(this,W,[]);v(this,L,[]);f(this,W,e.routers)}add(e,t,r){if(!o(this,L))throw new Error(bt);o(this,L).push([e,t,r])}match(e,t){if(!o(this,L))throw new Error("Fatal error");const r=o(this,W),a=o(this,L),s=r.length;let n=0,i;for(;n<s;n++){const d=r[n];try{for(let c=0,l=a.length;c<l;c++)d.add(...a[c]);i=d.match(e,t)}catch(c){if(c instanceof yt)continue;throw c}this.match=d.match.bind(d),f(this,W,[d]),f(this,L,void 0);break}if(n===s)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,i}get activeRouter(){if(o(this,L)||o(this,W).length!==1)throw new Error("No active router has been determined yet.");return o(this,W)[0]}},W=new WeakMap,L=new WeakMap,it),ve=Object.create(null),Y,A,ae,ge,O,U,ee,be,fr=(be=class{constructor(t,r,a){v(this,U);v(this,Y);v(this,A);v(this,ae);v(this,ge,0);v(this,O,ve);if(f(this,A,a||Object.create(null)),f(this,Y,[]),t&&r){const s=Object.create(null);s[t]={handler:r,possibleKeys:[],score:0},f(this,Y,[s])}f(this,ae,[])}insert(t,r,a){f(this,ge,++Ye(this,ge)._);let s=this;const n=Lt(r),i=[];for(let d=0,c=n.length;d<c;d++){const l=n[d],u=n[d+1],m=Bt(l,u),p=Array.isArray(m)?m[0]:l;if(p in o(s,A)){s=o(s,A)[p],m&&i.push(m[1]);continue}o(s,A)[p]=new be,m&&(o(s,ae).push(m),i.push(m[1])),s=o(s,A)[p]}return o(s,Y).push({[t]:{handler:a,possibleKeys:i.filter((d,c,l)=>l.indexOf(d)===c),score:o(this,ge)}}),s}search(t,r){var c;const a=[];f(this,O,ve);let n=[this];const i=lt(r),d=[];for(let l=0,u=i.length;l<u;l++){const m=i[l],p=l===u-1,w=[];for(let R=0,b=n.length;R<b;R++){const x=n[R],E=o(x,A)[m];E&&(f(E,O,o(x,O)),p?(o(E,A)["*"]&&a.push(...P(this,U,ee).call(this,o(E,A)["*"],t,o(x,O))),a.push(...P(this,U,ee).call(this,E,t,o(x,O)))):w.push(E));for(let k=0,y=o(x,ae).length;k<y;k++){const X=o(x,ae)[k],S=o(x,O)===ve?{}:{...o(x,O)};if(X==="*"){const H=o(x,A)["*"];H&&(a.push(...P(this,U,ee).call(this,H,t,o(x,O))),f(H,O,S),w.push(H));continue}const[$e,je,Q]=X;if(!m&&!(Q instanceof RegExp))continue;const C=o(x,A)[$e],He=i.slice(l).join("/");if(Q instanceof RegExp){const H=Q.exec(He);if(H){if(S[je]=H[0],a.push(...P(this,U,ee).call(this,C,t,o(x,O),S)),Object.keys(o(C,A)).length){f(C,O,S);const ye=((c=H[0].match(/\//))==null?void 0:c.length)??0;(d[ye]||(d[ye]=[])).push(C)}continue}}(Q===!0||Q.test(m))&&(S[je]=m,p?(a.push(...P(this,U,ee).call(this,C,t,S,o(x,O))),o(C,A)["*"]&&a.push(...P(this,U,ee).call(this,o(C,A)["*"],t,S,o(x,O)))):(f(C,O,S),w.push(C)))}}n=w.concat(d.shift()??[])}return a.length>1&&a.sort((l,u)=>l.score-u.score),[a.map(({handler:l,params:u})=>[l,u])]}},Y=new WeakMap,A=new WeakMap,ae=new WeakMap,ge=new WeakMap,O=new WeakMap,U=new WeakSet,ee=function(t,r,a,s){const n=[];for(let i=0,d=o(t,Y).length;i<d;i++){const c=o(t,Y)[i],l=c[r]||c[N],u={};if(l!==void 0&&(l.params=Object.create(null),n.push(l),a!==ve||s&&s!==ve))for(let m=0,p=l.possibleKeys.length;m<p;m++){const w=l.possibleKeys[m],R=u[l.score];l.params[w]=s!=null&&s[w]&&!R?s[w]:a[w]??(s==null?void 0:s[w]),u[l.score]=!0}}return n},be),ne,ot,hr=(ot=class{constructor(){h(this,"name","TrieRouter");v(this,ne);f(this,ne,new fr)}add(e,t,r){const a=dt(t);if(a){for(let s=0,n=a.length;s<n;s++)o(this,ne).insert(e,a[s],r);return}o(this,ne).insert(e,t,r)}match(e,t){return o(this,ne).search(e,t)}},ne=new WeakMap,ot),Pt=class extends sr{constructor(e={}){super(e),this.router=e.router??new pr({routers:[new mr,new hr]})}},gr=e=>{const r={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},a=(n=>typeof n=="string"?n==="*"?()=>n:i=>n===i?i:null:typeof n=="function"?n:i=>n.includes(i)?i:null)(r.origin),s=(n=>typeof n=="function"?n:Array.isArray(n)?()=>n:()=>[])(r.allowMethods);return async function(i,d){var u;function c(m,p){i.res.headers.set(m,p)}const l=await a(i.req.header("origin")||"",i);if(l&&c("Access-Control-Allow-Origin",l),r.credentials&&c("Access-Control-Allow-Credentials","true"),(u=r.exposeHeaders)!=null&&u.length&&c("Access-Control-Expose-Headers",r.exposeHeaders.join(",")),i.req.method==="OPTIONS"){r.origin!=="*"&&c("Vary","Origin"),r.maxAge!=null&&c("Access-Control-Max-Age",r.maxAge.toString());const m=await s(i.req.header("origin")||"",i);m.length&&c("Access-Control-Allow-Methods",m.join(","));let p=r.allowHeaders;if(!(p!=null&&p.length)){const w=i.req.header("Access-Control-Request-Headers");w&&(p=w.split(/\s*,\s*/))}return p!=null&&p.length&&(c("Access-Control-Allow-Headers",p.join(",")),i.res.headers.append("Vary","Access-Control-Request-Headers")),i.res.headers.delete("Content-Length"),i.res.headers.delete("Content-Type"),new Response(null,{headers:i.res.headers,status:204,statusText:"No Content"})}await d(),r.origin!=="*"&&i.header("Vary","Origin",{append:!0})}},br=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,et=(e,t=vr)=>{const r=/\.([a-zA-Z0-9]+?)$/,a=e.match(r);if(!a)return;let s=t[a[1]];return s&&s.startsWith("text")&&(s+="; charset=utf-8"),s},yr={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},vr=yr,xr=(...e)=>{let t=e.filter(s=>s!=="").join("/");t=t.replace(new RegExp("(?<=\\/)\\/+","g"),"");const r=t.split("/"),a=[];for(const s of r)s===".."&&a.length>0&&a.at(-1)!==".."?a.pop():s!=="."&&a.push(s);return a.join("/")||"."},Et={br:".br",zstd:".zst",gzip:".gz"},wr=Object.keys(Et),kr="index.html",Pr=e=>{const t=e.root??"./",r=e.path,a=e.join??xr;return async(s,n)=>{var u,m,p,w;if(s.finalized)return n();let i;if(e.path)i=e.path;else try{if(i=decodeURIComponent(s.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(i))throw new Error}catch{return await((u=e.onNotFound)==null?void 0:u.call(e,s.req.path,s)),n()}let d=a(t,!r&&e.rewriteRequestPath?e.rewriteRequestPath(i):i);e.isDir&&await e.isDir(d)&&(d=a(d,kr));const c=e.getContent;let l=await c(d,s);if(l instanceof Response)return s.newResponse(l.body,l);if(l){const R=e.mimes&&et(d,e.mimes)||et(d);if(s.header("Content-Type",R||"application/octet-stream"),e.precompressed&&(!R||br.test(R))){const b=new Set((m=s.req.header("Accept-Encoding"))==null?void 0:m.split(",").map(x=>x.trim()));for(const x of wr){if(!b.has(x))continue;const E=await c(d+Et[x],s);if(E){l=E,s.header("Content-Encoding",x),s.header("Vary","Accept-Encoding",{append:!0});break}}}return await((p=e.onFound)==null?void 0:p.call(e,d,s)),s.body(l)}await((w=e.onNotFound)==null?void 0:w.call(e,d,s)),await n()}},Er=async(e,t)=>{let r;t&&t.manifest?typeof t.manifest=="string"?r=JSON.parse(t.manifest):r=t.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?r=JSON.parse(__STATIC_CONTENT_MANIFEST):r=__STATIC_CONTENT_MANIFEST;let a;t&&t.namespace?a=t.namespace:a=__STATIC_CONTENT;const s=r[e];if(!s)return null;const n=await a.get(s,{type:"stream"});return n||null},Rr=e=>async function(r,a){return Pr({...e,getContent:async n=>Er(n,{manifest:e.manifest,namespace:e.namespace?e.namespace:r.env?r.env.__STATIC_CONTENT:void 0})})(r,a)},qr=e=>Rr(e);const Nr=[{id:"milwaukee-workstation",brand:"milwaukee",name:"PV5 밀워키 워크스테이션",fullName:"PV5 기아 밀워키 워크스테이션",description:"격벽타공판 + 격벽2단선반 + 워크스페이스 + 툴박스",price:485e4,image:"/static/images/milwaukee-workstation.jpg",sections:[{title:"기초자재",items:[{name:"태고합판 / 알루미늄체크판 / 논슬립",quantity:"1식"}]},{title:"격벽타공판",items:[{name:"M 격벽타공판",quantity:1},{name:"M 타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]},{title:"격벽2단선반",items:[{name:"M 2단 트레이",quantity:1},{name:"M 2단 트레이 로고",quantity:1},{name:"M 2단 프레임",quantity:2},{name:"M 트레이보강대",quantity:4}]},{title:"워크스페이스",items:[{name:"M 워크 타공판",quantity:1},{name:"M 워크 프레임 / 로고",quantity:"각 1"},{name:"M 워크 상판로고",quantity:1},{name:"M 3단 트레이/워크트레이",quantity:1},{name:"M 워크 세로보강대 (좌,우측)",quantity:2},{name:"M 워크 조명커버",quantity:1},{name:"M 트레이보강대",quantity:2},{name:"M 워크 트렁크브라켓",quantity:1},{name:"M 도어브라켓 - 우",quantity:1}]},{title:"툴박스",items:[{name:"팩아웃 거치대",quantity:4},{name:"팩아웃 라지 툴박스",quantity:1},{name:"오픈형 툴박스",quantity:1}]}]},{id:"milwaukee-smart",brand:"milwaukee",name:"PV5 밀워키 스마트 에디션",fullName:"PV5 기아 밀워키 스마트 에디션",description:"격벽타공판 + 격벽2단선반 + 3단선반 + 툴박스",price:52e5,image:"/static/images/milwaukee-smart.jpg",hasPositionOption:!0,sections:[{title:"기초자재",items:[{name:"태고합판 / 알루미늄체크판 / 논슬립",quantity:"1식"}]},{title:"격벽타공판",items:[{name:"M 격벽타공판",quantity:1},{name:"M 타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]},{title:"격벽2단선반",items:[{name:"M 2단 트레이",quantity:1},{name:"M 2단 트레이 로고",quantity:1},{name:"M 2단 프레임",quantity:2},{name:"M 트레이보강대",quantity:4}]},{title:"3단선반 (좌/우측)",items:[{name:"M 3단 트레이/워크트레이",quantity:2},{name:"M 3단 트레이 로고",quantity:1},{name:"M 3단 프레임 로고 (좌/우측)",quantity:"각 1"},{name:"M 3단 프레임",quantity:1},{name:"M 트레이보강대",quantity:6},{name:"M 트렁크 브라켓",quantity:1},{name:"M 도어브라켓 (좌)",quantity:1},{name:"M 도어브라켓 (우)",quantity:1}]},{title:"툴박스",items:[{name:"팩아웃 거치대",quantity:8},{name:"팩아웃 라지 툴박스",quantity:1},{name:"오픈형 툴박스",quantity:1}]}]},{id:"milwaukee-3shelf-parts",brand:"milwaukee",name:"PV5 밀워키 3단 부품선반",fullName:"PV5 기아 밀워키 3단 부품선반 (좌/우측)",description:"밀워키 단품 - 3단 부품선반",price:18e5,image:"/static/images/milwaukee-3shelf-parts.jpg",hasPositionOption:!0,sections:[{title:"3단 부품선반 (좌/우측)",items:[{name:"M 부품 트레이",quantity:2},{name:"M 부품 트레이 로고",quantity:1},{name:"M 부품 프레임 (일반)",quantity:1},{name:"M 부품 프레임 (좌측/우측)",quantity:"각 1"},{name:"M 부품 보강대",quantity:6},{name:"M 트렁크 브라켓",quantity:1},{name:"M 도어브라켓 (좌/우)",quantity:"각 1"}]}]},{id:"milwaukee-3shelf-standard",brand:"milwaukee",name:"PV5 밀워키 3단 선반",fullName:"PV5 기아 밀워키 3단 선반 (좌/우측)",description:"밀워키 단품 - 3단 선반",price:19e5,image:"/static/images/milwaukee-3shelf-standard.jpg",hasPositionOption:!0,sections:[{title:"3단 선반 (좌/우측)",items:[{name:"M 3단 트레이/워크트레이",quantity:2},{name:"M 3단 트레이 로고",quantity:1},{name:"M 3단 프레임 로고 (좌/우측)",quantity:"각 1"},{name:"M 3단 프레임",quantity:1},{name:"M 트레이 보강대",quantity:6},{name:"M 트렁크 브라켓",quantity:1},{name:"M 도어브라켓 (좌/우)",quantity:"각 1"}]}]},{id:"milwaukee-2shelf-partition",brand:"milwaukee",name:"PV5 밀워키 2단 선반",fullName:"PV5 카고 밀워키 2단 선반",description:"밀워키 단품 - 2단 선반",price:15e5,image:"/static/images/milwaukee-2shelf-partition.jpg",sections:[{title:"격벽 2단선반",items:[{name:"M 2단 트레이",quantity:1},{name:"M 2단 트레이 로고",quantity:1},{name:"M 2단 프레임",quantity:2},{name:"M 트레이보강대",quantity:4}]}]},{id:"milwaukee-partition-panel",brand:"milwaukee",name:"PV5 밀워키 격벽타공판",fullName:"PV5 카고 밀워키 격벽타공판",description:"밀워키 단품 - 격벽타공판",price:12e5,image:"/static/images/milwaukee-partition-panel.jpg",sections:[{title:"격벽타공판",items:[{name:"M 격벽타공판",quantity:1},{name:"M 타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]}]},{id:"milwaukee-floor-board",brand:"milwaukee",name:"적재함 평탄화 보드",fullName:"적재함 평탄화 보드 (태고합판 + 알루미늄체크판 + 논슬립)",description:"공통 단품 - 적재함 평탄화 보드",price:8e5,image:"/static/images/floor-board.jpg",sections:[{title:"적재함 평탄화 보드",items:[{name:"태고합판",quantity:1},{name:"알루미늄체크판",quantity:1},{name:"논슬립",quantity:1}]}]}],jr=[{id:"kia-workstation",brand:"kia",name:"기아 PV5 워크스테이션",fullName:"기아 PV5 순정형 워크스테이션",description:"격벽타공판 + 3단부품선반 + 워크스페이스",price:42e5,image:"/static/images/kia-workstation.jpg",sections:[{title:"기초자재",items:[{name:"태고합판 / 알루미늄체크판 / 논슬립",quantity:"1식"}]},{title:"격벽타공판",items:[{name:"격벽타공판",quantity:1},{name:"타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]},{title:"3단부품선반",items:[{name:"부품 트레이",quantity:2},{name:"부품 트레이 로고",quantity:1},{name:"부품 프레임 (일반)",quantity:1},{name:"부품 프레임 (좌측)",quantity:1},{name:"부품 보강대",quantity:6},{name:"트렁크 브라켓",quantity:1},{name:"도어브라켓 (좌측/우측)",quantity:1}]},{title:"워크스페이스",items:[{name:"워크 타공판",quantity:1},{name:"워크 프레임 / 로고",quantity:"각 1"},{name:"워크 상판로고",quantity:1},{name:"3단 트레이/워크트레이",quantity:1},{name:"워크 세로보강대",quantity:2},{name:"워크 조명커버",quantity:1},{name:"트레이보강대",quantity:2},{name:"트렁크보강대",quantity:1},{name:"도어브라켓 - 우",quantity:1},{name:"트렁크 브라켓",quantity:1}]}]},{id:"kia-smart",brand:"kia",name:"기아 PV5 스마트 패키지",fullName:"기아 PV5 순정형 스마트 패키지",description:"격벽타공판 + 2단선반 + 3단선반",price:45e5,image:"/static/images/kia-smart.jpg",hasPositionOption:!0,sections:[{title:"기초자재",items:[{name:"태고합판 / 알루미늄체크판 / 논슬립",quantity:"1식"}]},{title:"격벽타공판",items:[{name:"격벽타공판",quantity:1},{name:"타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]},{title:"2단선반",items:[{name:"2단 트레이",quantity:1},{name:"2단 트레이 로고",quantity:1},{name:"2단 프레임",quantity:2},{name:"트레이보강대",quantity:4}]},{title:"3단선반 (좌/우측)",items:[{name:"3단 트레이/워크트레이",quantity:2},{name:"3단 트레이 로고",quantity:1},{name:"3단 프레임 로고 (좌/우측)",quantity:"각 1"},{name:"3단 프레임",quantity:1},{name:"트레이보강대",quantity:6},{name:"트렁크보강대",quantity:1},{name:"도어브라켓 (좌)",quantity:1},{name:"도어브라켓 (우)",quantity:1},{name:"트렁크브라켓 (좌,우)",quantity:1}]}]},{id:"kia-3shelf-parts",brand:"kia",name:"기아 PV5 3단 부품선반",fullName:"기아 PV5 순정형 3단 부품선반 (좌/우측)",description:"기아 단품 - 3단 부품선반",price:16e5,image:"/static/images/kia-3shelf-parts.jpg",hasPositionOption:!0,sections:[{title:"3단 부품선반 (좌/우측)",items:[{name:"부품 트레이",quantity:2},{name:"부품 트레이 로고",quantity:1},{name:"부품 프레임 (일반)",quantity:1},{name:"부품 프레임 (좌측/우측)",quantity:"각 1"},{name:"부품 보강대",quantity:6},{name:"트렁크 브라켓",quantity:1},{name:"도어브라켓 (좌)",quantity:1},{name:"도어브라켓 (우)",quantity:1}]}]},{id:"kia-3shelf-standard",brand:"kia",name:"기아 PV5 3단 선반",fullName:"기아 PV5 순정형 3단 선반 (좌/우측)",description:"기아 단품 - 3단 선반",price:17e5,image:"/static/images/kia-3shelf-standard.jpg",hasPositionOption:!0,sections:[{title:"3단 선반 (좌/우측)",items:[{name:"3단 트레이/워크트레이",quantity:2},{name:"3단 트레이 로고",quantity:1},{name:"3단 프레임 로고 (좌/우측)",quantity:"각 1"},{name:"3단 프레임",quantity:1},{name:"트레이 보강대",quantity:6},{name:"트렁크 보강대",quantity:1},{name:"도어브라켓 (좌)",quantity:1},{name:"도어브라켓 (우)",quantity:1},{name:"트렁크브라켓 (좌,우)",quantity:1}]}]},{id:"kia-2shelf-partition",brand:"kia",name:"PV5 카고 격벽 2단선반",fullName:"PV5 카고 격벽 2단선반",description:"기아 단품 - 격벽 2단선반",price:14e5,image:"/static/images/kia-2shelf-partition.jpg",sections:[{title:"격벽 2단선반",items:[{name:"2단 트레이",quantity:1},{name:"2단 트레이 로고",quantity:1},{name:"2단 프레임",quantity:2},{name:"트레이보강대",quantity:4}]}]},{id:"kia-partition-panel",brand:"kia",name:"기아 PV5 격벽타공판",fullName:"기아 PV5 순정형 격벽타공판",description:"기아 단품 - 격벽타공판",price:11e5,image:"/static/images/kia-partition-panel.jpg",sections:[{title:"격벽타공판",items:[{name:"격벽타공판",quantity:1},{name:"타공판보강대",quantity:3},{name:"브라켓 (상/중/하)",quantity:"각 2"}]}]},{id:"kia-floor-board",brand:"kia",name:"적재함 평탄화 보드",fullName:"적재함 평탄화 보드 (태고합판 + 알루미늄체크판 + 논슬립)",description:"공통 단품 - 적재함 평탄화 보드",price:8e5,image:"/static/images/floor-board.jpg",sections:[{title:"적재함 평탄화 보드",items:[{name:"태고합판",quantity:1},{name:"알루미늄체크판",quantity:1},{name:"논슬립",quantity:1}]}]}],Rt=[...Nr,...jr];function qt(e){return Rt.find(t=>t.id===e)}const _=new Pt;_.use("/api/*",gr());_.use("/static/*",qr({root:"./public"}));_.get("/api/packages",e=>e.json({packages:Rt}));_.get("/api/packages/:id",e=>{const t=e.req.param("id"),r=qt(t);return r?e.json({package:r}):e.json({error:"Package not found"},404)});_.post("/api/ocr",async e=>{var t,r,a;try{const n=(await e.req.parseBody()).file;if(!n)return e.json({error:"No file uploaded"},400);console.log("OCR request received:",n.name,n.type,n.size);const i=await n.arrayBuffer(),d=Buffer.from(i).toString("base64"),c=(t=e.env)==null?void 0:t.GOOGLE_VISION_API_KEY;if(!c)return console.error("GOOGLE_VISION_API_KEY not found in environment"),e.json({success:!1,data:{customerName:"",phone:"",address:"",productName:"",productCode:"",orderNumber:"",orderDate:new Date().toLocaleDateString("ko-KR"),ocrRawText:"",aiSuccess:!1,recognitionSuccess:!1},message:"OCR 서비스 설정이 필요합니다. 관리자에게 문의하세요."},200);console.log("Calling Google Cloud Vision API...");const l=await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${c}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({requests:[{image:{content:d},features:[{type:"DOCUMENT_TEXT_DETECTION",maxResults:1}]}]})});if(!l.ok){const k=await l.text();throw console.error("Google Vision API error:",l.status,k),new Error(`Google Vision API error: ${l.status}`)}const u=await l.json();console.log("Google Vision API response received");const m=(a=(r=u.responses)==null?void 0:r[0])==null?void 0:a.fullTextAnnotation,p=(m==null?void 0:m.text)||"",w=!!p;if(console.log("Extracted OCR text length:",p.length),console.log("OCR text preview:",p.substring(0,200)),!p||p.length<10)return console.warn("No text detected in image"),e.json({success:!1,data:{customerName:"",phone:"",address:"",productName:"",productCode:"",orderNumber:"",orderDate:new Date().toLocaleDateString("ko-KR"),ocrRawText:p,aiSuccess:!0,recognitionSuccess:!1},message:"이미지에서 텍스트를 인식할 수 없습니다. 이미지 품질을 확인해주세요."},200);const b=p?(k=>{var Je;const y={outputDate:"",deliveryNumber:"",receiverName:"",ordererName:"",receiverAddress:"",receiverPhone:"",deliveryMemo:"",orderNumber:"",productCode:"",productName:""};if(!k||k.length<5)return y;console.log("Parsing OCR text (우측 수령자 정보만):",k);const X=k.match(/(?:수령자|받는사람|수령인)([\s\S]*?)(?:공급자|SEQ\.|이하여백|$)/i),S=X?X[1]:k;console.log("Target text (수령자 영역):",S);const $e=[/출력일자[\s\n:：]*(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일/i,/출력일[\s\n:：]*(\d{4})[.-](\d{1,2})[.-](\d{1,2})/i,/(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일/i];for(const q of $e){const g=k.match(q);if(g){y.outputDate=`${g[1]}년 ${g[2].padStart(2,"0")}월 ${g[3].padStart(2,"0")}일`,console.log("Output date found:",y.outputDate);break}}const je=[/배송번호[\s\n]+(\d{8})/i];for(const q of je){const g=k.match(q);if(g&&g[1]){y.deliveryNumber=g[1].trim(),console.log("Delivery number found:",y.deliveryNumber);break}}const Q=[/수령자명[\s\n]+([가-힣]{2,10})(?:\s|\n|$)/i];for(const q of Q){const g=k.match(q);if(g&&g[1]){y.receiverName=g[1].trim(),console.log("Receiver name found:",y.receiverName);break}}const C=[/주문자명[\s\n]+([가-힣]{2,10})(?:\s|\n|\(|수|$)/i];for(const q of C){const g=k.match(q);if(g&&g[1]){y.ordererName=g[1].trim(),console.log("Orderer name found:",y.ordererName);break}}!y.ordererName&&y.receiverName&&(y.ordererName=y.receiverName);const He=[/수령자\s*주소[\s\n]+(\(\d{5}\)\s*[^\n]+)[\s\n]+([^\n]+?)(?=\n0|\n수령자|$)/i,/수령자\s*주소[\s\n]+(\(\d{5}\)\s*[^\n]+)/i,/수령자\s*주소[\s\n]+([^\n]+)[\s\n]+([^\n]+?)(?=\n0|\n수령자|$)/i,/수령자\s*주소[\s\n]+([^\n]+?)(?=\n0|\n수령자|$)/i,/주소[\s\n]+([^\n]+(?:\n[^\n]+)?)/i];for(const q of He){const g=k.match(q);if(g){if(g[2]){const _t=g[1].trim(),St=g[2].trim();y.receiverAddress=`${_t} ${St}`}else g[1]&&(y.receiverAddress=g[1].trim());console.log("Receiver address found:",y.receiverAddress);break}}const H=[/(010)[-\s]*(\d{4})[-\s]*\n수령자\s*연락처1[\s\n]+수령자\s*연락처2[\s\n]+(\d{4})/i,/수령자\s*연락처1[\s\n]+(010[-\s]?\d{3,4}[-\s]?\d{4})/i];for(const q of H){const g=k.match(q);if(g){g[3]?y.receiverPhone=`${g[1]}-${g[2]}-${g[3]}`:g[1]&&(y.receiverPhone=g[1].replace(/\s/g,"")),console.log("Receiver phone found:",y.receiverPhone);break}}const ye=[/배송메모[\s\n]+([가-힣\w\s]{3,50})(?=\n상품명|\n주문번호|$)/i];for(const q of ye){const g=k.match(q);if(g&&g[1]&&!g[1].includes("상품명")&&!g[1].includes("주문")){y.deliveryMemo=g[1].trim(),console.log("Delivery memo found:",y.deliveryMemo);break}}const Ge=[/주문번호[\s\n]+(\d{18,20})/i,/(\d{18,20})/];for(const q of Ge){const g=k.match(q);if(g&&g[1]){y.orderNumber=g[1].trim(),console.log("Order number found:",y.orderNumber);break}}const ze=k.match(/사업자등록번호[\s\n:：]+(\d{10})/i),Ve=ze?ze[1]:null,jt=/1\/1[\s\n]+(\d{9})(?!\d)/i,Ot=/상품번호[\s\n:：]+(\d{8,10})/i,At=/(?:^|\n)(\d{9})(?!\d)/gm,Oe=k.match(jt),Ae=k.match(Ot);if(Oe&&Oe[1]&&Oe[1]!==Ve)y.productCode=Oe[1],console.log("Product code found (pattern 1):",y.productCode);else if(Ae&&Ae[1]&&Ae[1]!==Ve)y.productCode=Ae[1],console.log("Product code found (pattern 2):",y.productCode);else{let q;for(;(q=At.exec(k))!==null;)if(q[1]!==Ve&&!((Je=y.deliveryNumber)!=null&&Je.includes(q[1]))){y.productCode=q[1],console.log("Product code found (pattern 3):",y.productCode);break}}const Tt=[/(?:상품명|제품명|품명)[\s:：]*([^\n]{5,100})/i,/PV5[\s가-힣\w]+(?:워크스테이션|스마트|선반|격벽|밀워키|카고)/i];for(const q of Tt){const g=k.match(q);if(g){y.productName=(g[1]||g[0]).trim(),console.log("Product name found:",y.productName);break}}return console.log("Final parsed data:",y),y})(p):{},x=b.receiverName&&b.receiverName.length>=2||b.receiverPhone&&b.receiverPhone.length>=10||b.receiverAddress&&b.receiverAddress.length>=10||b.orderNumber&&b.orderNumber.length>=8;console.log("Validation result:",{hasValidData:x,receiverName:b.receiverName,receiverPhone:b.receiverPhone,receiverAddress:b.receiverAddress,orderNumber:b.orderNumber});const E={outputDate:b.outputDate||"",deliveryNumber:b.deliveryNumber||"",receiverName:b.receiverName||"",ordererName:b.ordererName||"",receiverAddress:b.receiverAddress||"",receiverPhone:b.receiverPhone||"",deliveryMemo:b.deliveryMemo||"",orderNumber:b.orderNumber||"",productCode:b.productCode||"",productName:b.productName||"",ocrRawText:p,aiSuccess:w,recognitionSuccess:x};return console.log("Final OCR result:",E),!x&&w?(console.warn("OCR recognition failed - no valid data extracted"),e.json({success:!1,data:E,message:"OCR 인식에 실패했습니다. 이미지 품질을 확인하거나 수동으로 입력해주세요."},200)):w?e.json({success:!0,data:E}):(console.warn("AI binding not available or failed"),e.json({success:!1,data:E,message:"OCR 서비스를 사용할 수 없습니다. Cloudflare Pages에 배포 후 사용 가능합니다."},200))}catch(s){return console.error("OCR Error:",s),e.json({error:"OCR processing failed",message:s instanceof Error?s.message:"Unknown error",suggestion:"수동으로 입력해주세요."},500)}});_.post("/api/generate-report",async e=>{try{const t=await e.req.json(),{customerInfo:r,packageId:a,installDate:s,installAddress:n,installTime:i,notes:d}=t,c=qt(a);if(!c)return e.json({error:"Invalid package ID"},400);const l={id:`INSTALL-${Date.now()}`,createdAt:new Date().toISOString(),customerInfo:r,package:c,installDate:s,installAddress:n,installTime:i,notes:d,status:"pending"};return e.json({success:!0,report:l})}catch(t){return console.error("Report Generation Error:",t),e.json({error:"Failed to generate report"},500)}});_.post("/api/send-email",async e=>{try{const{env:t}=e,r=await e.req.json(),{recipientEmail:a,customerInfo:s,packages:n,installDate:i,installTime:d,installAddress:c,notes:l,attachmentImage:u,attachmentFileName:m,attachmentContentType:p}=r;if(!t.RESEND_API_KEY)return console.warn("RESEND_API_KEY not configured"),e.json({success:!1,message:"이메일 서비스가 설정되지 않았습니다. 관리자에게 문의하세요."},200);const w=n.map(k=>`
      <li><strong>${k.fullName||k.name}</strong></li>
    `).join(""),R=`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: 'Apple SD Gothic Neo', 'Malgun Gothic', sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #2563eb; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background-color: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
          .section { margin-bottom: 25px; background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #2563eb; }
          .section-title { font-size: 18px; font-weight: bold; color: #1e40af; margin-bottom: 10px; }
          .info-row { margin: 8px 0; }
          .label { font-weight: bold; color: #4b5563; }
          .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
          ul { list-style-type: none; padding-left: 0; }
          li { padding: 5px 0; }
        </style>
        <script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"><\/script>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚗 PV5 시공(예약) 확인서</h1>
          </div>
          <div class="content">
            <div class="section">
              <div class="section-title">👤 고객 정보</div>
              <div class="info-row"><span class="label">고객명:</span> ${(s==null?void 0:s.receiverName)||"-"}</div>
              <div class="info-row"><span class="label">연락처:</span> ${(s==null?void 0:s.receiverPhone)||"-"}</div>
              <div class="info-row"><span class="label">주소:</span> ${(s==null?void 0:s.receiverAddress)||"-"}</div>
              <div class="info-row"><span class="label">주문번호:</span> ${(s==null?void 0:s.orderNumber)||"-"}</div>
            </div>
            
            <div class="section">
              <div class="section-title">📦 선택 제품</div>
              <ul>${w}</ul>
            </div>
            
            <div class="section">
              <div class="section-title">📅 설치 정보</div>
              <div class="info-row"><span class="label">설치 날짜:</span> ${i||"-"}</div>
              <div class="info-row"><span class="label">설치 시간:</span> ${d||"-"}</div>
              <div class="info-row"><span class="label">설치 주소:</span> ${c||"-"}</div>
              ${l?`<div class="info-row"><span class="label">특이사항:</span> ${l}</div>`:""}
            </div>
          </div>
          <div class="footer">
            <p>© 2026 사인마스터 PV5 시공관리 시스템</p>
            <p>이 메일은 PV5 시공 확인 점검표 시스템에서 자동으로 발송되었습니다.</p>
          </div>
        </div>
      </body>
      </html>
    `,b={from:"PV5 시공관리 <onboarding@resend.dev>",to:[a],subject:`[PV5 시공(예약) 확인서] ${(s==null?void 0:s.receiverName)||"고객"}님 시공(예약) 확인서`,html:R};u&&m&&(console.log("Adding attachment to email:",m),b.attachments=[{filename:m,content:u,content_type:p||"image/png"}]);const x=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${t.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify(b)}),E=await x.json();return x.ok?(console.log("Email sent successfully:",E),e.json({success:!0,message:"이메일이 성공적으로 발송되었습니다!",emailId:E.id})):(console.error("Resend API Error:",E),e.json({success:!1,message:"이메일 발송에 실패했습니다. 다시 시도해주세요.",error:E},200))}catch(t){return console.error("Email sending error:",t),e.json({success:!1,message:"이메일 발송 중 오류가 발생했습니다.",error:t instanceof Error?t.message:"Unknown error"},500)}});_.post("/api/upload-image",async e=>{try{const{env:t}=e,a=(await e.req.formData()).get("image");if(!a)return e.json({success:!1,message:"이미지 파일이 없습니다."},400);const s=`images/${Date.now()}-${Math.random().toString(36).substring(7)}-${a.name}`;return await t.R2.put(s,a.stream()),e.json({success:!0,imageKey:s,filename:a.name})}catch(t){return console.error("Image upload error:",t),e.json({success:!1,message:"이미지 업로드 실패",error:t instanceof Error?t.message:"Unknown error"},500)}});_.post("/api/reports/save",async e=>{try{const{env:t}=e,r=await e.req.json(),{reportId:a,customerInfo:s,packages:n,packagePositions:i,installDate:d,installTime:c,installAddress:l,notes:u,installerName:m,attachmentImage:p,attachmentFileName:w}=r;let R=null;if(p){R=`images/${Date.now()}-${a}-${w||"attachment.jpg"}`;const x=Buffer.from(p,"base64");await t.R2.put(R,x)}const b=a||`REPORT-${Date.now()}`;return await t.DB.prepare(` // UPDATED
      INSERT OR REPLACE INTO reports ( // UPDATED
        report_id, customer_info, packages, package_positions, // UPDATED
        install_date, install_time, install_address, notes, // UPDATED
        installer_name, image_key, image_filename, // UPDATED
        created_at, updated_at // UPDATED
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now')) // UPDATED
    `).bind(b,JSON.stringify(s),JSON.stringify(n),JSON.stringify(i),d,c,l,u,m,R,w).run(),console.log("Report saved to D1:",b),e.json({success:!0,message:"시공 확인서가 저장되었습니다!",reportId:b})}catch(t){return console.error("Report save error:",t),e.json({success:!1,message:"저장 중 오류가 발생했습니다.",error:t instanceof Error?t.message:"Unknown error"},500)}});_.get("/api/reports/list",async e=>{try{const{env:t}=e,r=t.DB.prepare(`
      SELECT 
        id, report_id, customer_info, packages, package_positions,
        install_date, install_time, install_address, notes,
        installer_name, image_key, image_filename,
        created_at, updated_at
      FROM reports
      ORDER BY created_at DESC
      LIMIT 100
    `),{results:a}=await r.all(),s=a.map(n=>({reportId:n.report_id,id:n.report_id,customerInfo:n.customer_info?JSON.parse(n.customer_info):null,packages:n.packages?JSON.parse(n.packages):[],packagePositions:n.package_positions?JSON.parse(n.package_positions):{},installDate:n.install_date,installTime:n.install_time,installAddress:n.install_address,notes:n.notes,installerName:n.installer_name,imageKey:n.image_key,imageFilename:n.image_filename,createdAt:n.created_at,updatedAt:n.updated_at}));return e.json({success:!0,reports:s})}catch(t){return console.error("Report list error:",t),e.json({success:!1,reports:[],error:t instanceof Error?t.message:"Unknown error"},500)}});_.get("/api/reports/:id",async e=>{try{const{env:t}=e,r=e.req.param("id"),{results:a}=await t.DB.prepare(` // UPDATED
      SELECT  // UPDATED
        id, report_id, customer_info, packages, package_positions, // UPDATED
        install_date, install_time, install_address, notes, // UPDATED
        installer_name, image_key, image_filename, // UPDATED
        created_at, updated_at // UPDATED
      FROM reports // UPDATED
      WHERE report_id = ? // UPDATED
    `).bind(r).all();if(a.length===0)return e.json({success:!1,message:"시공 확인서를 찾을 수 없습니다."},404);const s=a[0],n={reportId:s.report_id,id:s.report_id,customerInfo:s.customer_info?JSON.parse(s.customer_info):null,packages:s.packages?JSON.parse(s.packages):[],packagePositions:s.package_positions?JSON.parse(s.package_positions):{},installDate:s.install_date,installTime:s.install_time,installAddress:s.install_address,notes:s.notes,installerName:s.installer_name,imageKey:s.image_key,imageFilename:s.image_filename,createdAt:s.created_at,updatedAt:s.updated_at};return e.json({success:!0,report:n})}catch(t){return console.error("Report load error:",t),e.json({success:!1,message:"불러오기 중 오류가 발생했습니다.",error:t instanceof Error?t.message:"Unknown error"},500)}});_.delete("/api/reports/:id",async e=>{try{const{env:t}=e,r=e.req.param("id");if(!t.REPORTS_KV)return e.json({success:!1,message:"KV 스토리지가 설정되지 않았습니다."},404);await t.REPORTS_KV.delete(r);const a="report-index",s=await t.REPORTS_KV.get(a);if(s){const i=JSON.parse(s).filter(d=>d.id!==r);await t.REPORTS_KV.put(a,JSON.stringify(i))}return e.json({success:!0,message:"시공 확인서가 삭제되었습니다."})}catch(t){return console.error("Report delete error:",t),e.json({success:!1,message:"삭제 중 오류가 발생했습니다.",error:t instanceof Error?t.message:"Unknown error"},500)}});_.get("/",e=>e.html(`
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PV5 시공(예약) 확인서 시스템</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .file-upload-area {
            border: 2px dashed #cbd5e0;
            transition: all 0.3s;
          }
          .file-upload-area:hover {
            border-color: #4299e1;
            background-color: #ebf8ff;
          }
          .package-card {
            transition: all 0.3s;
            cursor: pointer;
          }
          .package-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
          }
          .package-card.selected {
            border: 3px solid #4299e1;
            background-color: #ebf8ff;
          }
          .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
          }
          .step {
            flex: 1;
            text-align: center;
            padding: 1rem;
            border-bottom: 3px solid #e2e8f0;
            color: #a0aec0;
          }
          .step.active {
            border-bottom-color: #4299e1;
            color: #4299e1;
            font-weight: bold;
          }
          .step.completed {
            border-bottom-color: #48bb78;
            color: #48bb78;
          }
          
          /* 인쇄 전용 스타일 */
          @media print {
            /* body의 모든 자식 요소 중 모달 제외하고 숨김 */
            body > *:not(#previewModal) {
              display: none !important;
            }
            
            body {
              padding: 0 !important;
              margin: 0 !important;
              background: white !important;
            }
            
            /* 모달 배경 투명 */
            .modal-overlay {
              background: white !important;
              position: static !important;
              padding: 0 !important;
              display: block !important;
            }
            
            /* 모달 내용 전체 화면 */
            .modal-content {
              max-width: 100% !important;
              max-height: none !important;
              box-shadow: none !important;
              border-radius: 0 !important;
              margin: 0 !important;
              padding: 0 !important;
            }
            
            /* 헤더와 푸터 숨김 */
            .modal-header,
            .modal-footer {
              display: none !important;
            }
            
            /* 모달만 표시 */
            #previewModal {
              display: block !important;
              position: static !important;
              background: white !important;
            }
            
            /* 테두리 제거 */
            #previewModal .border-2 {
              border: none !important;
            }
          }
        </style>
        <script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"><\/script>
    </head>
    <body class="bg-gray-50">
        <div class="min-h-screen">
            <!-- Header -->
            <header class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-6 shadow-lg">
                <div class="container mx-auto px-4">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-4">
                            <img src="/static/kvan-logo.png" alt="K-VAN" class="h-12 w-auto bg-white px-3 py-1 rounded-lg">
                            <div>
                                <h1 class="text-3xl font-bold flex items-center">
                                    <i class="fas fa-clipboard-check mr-3"></i>
                                    PV5 시공(예약) 확인서 시스템
                                </h1>
                                <p class="text-blue-100 mt-2">거래명세서 자동 인식 → 제품 선택 → 설치 일정 확정 → PDF/메일 발송</p>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Content -->
            <main class="container mx-auto px-4 py-8">
                <!-- Step Indicator -->
                <div class="step-indicator bg-white rounded-lg shadow-md mb-8">
                    <div class="step active" id="step1">
                        <i class="fas fa-upload text-2xl mb-2"></i>
                        <div>1. 거래명세서 업로드</div>
                    </div>
                    <div class="step" id="step2">
                        <i class="fas fa-box text-2xl mb-2"></i>
                        <div>2. 제품 선택</div>
                    </div>
                    <div class="step" id="step3">
                        <i class="fas fa-calendar-alt text-2xl mb-2"></i>
                        <div>3. 설치 정보 입력</div>
                    </div>
                    <div class="step" id="step4">
                        <i class="fas fa-check-circle text-2xl mb-2"></i>
                        <div>4. 확인 및 발송</div>
                    </div>
                    <div class="step" id="step5">
                        <i class="fas fa-folder-open text-2xl mb-2"></i>
                        <div>5. 저장 문서 관리</div>
                    </div>
                </div>

                <!-- Step 1: 파일 업로드 -->
                <div id="upload-section" class="bg-white rounded-lg shadow-lg p-8 mb-8">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800">
                        <i class="fas fa-file-upload text-blue-600 mr-2"></i>
                        1단계: 거래명세서 업로드
                    </h2>
                    <div class="file-upload-area rounded-lg p-12 text-center cursor-pointer" id="dropZone">
                        <i class="fas fa-cloud-upload-alt text-6xl text-gray-400 mb-4"></i>
                        <p class="text-lg text-gray-600 mb-4">거래명세서 이미지를 드래그하거나 클릭하여 업로드</p>
                        <input type="file" id="fileInput" accept="image/*" class="hidden">
                        <div class="flex justify-center space-x-3">
                            <button onclick="document.getElementById('fileInput').click(); event.stopPropagation();" 
                                    class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                                <i class="fas fa-folder-open mr-2"></i>파일 선택
                            </button>
                            <button onclick="showManualInputForm(); event.stopPropagation();" 
                                    class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition">
                                <i class="fas fa-keyboard mr-2"></i>수동 입력
                            </button>
                        </div>
                        <p class="text-xs text-gray-500 mt-4">지원 형식: JPG, PNG, GIF (최대 10MB)</p>
                    </div>
                    <div id="uploadResult" class="mt-6 hidden">
                        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                            <h3 class="font-bold text-green-800 mb-2">
                                <i class="fas fa-check-circle mr-2"></i>자동 인식 완료
                            </h3>
                            <div id="ocrData" class="grid grid-cols-2 gap-4 text-sm"></div>
                        </div>
                    </div>
                </div>

                <!-- Step 2: 제품 선택 -->
                <div id="package-section" class="bg-white rounded-lg shadow-lg p-8 mb-8 hidden">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800">
                        <i class="fas fa-box-open text-blue-600 mr-2"></i>
                        2단계: 시공 제품 선택
                    </h2>
                    
                    <!-- 브랜드 선택 탭 -->
                    <div class="flex space-x-4 mb-6">
                        <button onclick="showBrand('milwaukee')" 
                                class="brand-tab flex-1 py-3 px-6 rounded-lg font-bold transition"
                                data-brand="milwaukee">
                            <i class="fas fa-tools mr-2"></i>밀워키 에디션
                        </button>
                        <button onclick="showBrand('kia')" 
                                class="brand-tab flex-1 py-3 px-6 rounded-lg font-bold transition"
                                data-brand="kia">
                            <i class="fas fa-car mr-2"></i>기아 순정형
                        </button>
                    </div>
                    
                    <!-- 제품 패키지 카드 -->
                    <div id="packageGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"></div>
                </div>

                <!-- Step 3: 설치 정보 입력 -->
                <div id="install-section" class="bg-white rounded-lg shadow-lg p-8 mb-8 hidden">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800">
                        <i class="fas fa-calendar-check text-blue-600 mr-2"></i>
                        3단계: 설치 일정 및 장소 확정
                    </h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">
                                <i class="fas fa-calendar mr-2"></i>설치 날짜
                            </label>
                            <input type="date" id="installDate" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">
                                <i class="fas fa-clock mr-2"></i>설치 시간
                            </label>
                            <div class="space-y-2">
                                <div class="flex gap-2">
                                    <button type="button" id="timePeriodAM" onclick="selectTimePeriod('AM')"
                                            class="flex-1 px-3 py-2 text-sm border-2 border-gray-300 rounded-lg hover:bg-gray-50">
                                        오전
                                    </button>
                                    <button type="button" id="timePeriodPM" onclick="selectTimePeriod('PM')"
                                            class="flex-1 px-3 py-2 text-sm border-2 border-gray-300 rounded-lg hover:bg-gray-50">
                                        오후
                                    </button>
                                </div>
                                <div class="grid grid-cols-5 gap-1">
                                    <button type="button" onclick="selectTimeHour('9')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">9시</button>
                                    <button type="button" onclick="selectTimeHour('10')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">10시</button>
                                    <button type="button" onclick="selectTimeHour('11')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">11시</button>
                                    <button type="button" onclick="selectTimeHour('12')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">12시</button>
                                    <button type="button" onclick="selectTimeHour('1')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">1시</button>
                                    <button type="button" onclick="selectTimeHour('2')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">2시</button>
                                    <button type="button" onclick="selectTimeHour('3')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">3시</button>
                                    <button type="button" onclick="selectTimeHour('4')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">4시</button>
                                    <button type="button" onclick="selectTimeHour('5')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">5시</button>
                                    <button type="button" onclick="selectTimeHour('6')" class="time-hour-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-blue-50">6시</button>
                                </div>
                                <div class="grid grid-cols-6 gap-1">
                                    <button type="button" onclick="selectTimeMinute('00')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">00분</button>
                                    <button type="button" onclick="selectTimeMinute('10')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">10분</button>
                                    <button type="button" onclick="selectTimeMinute('20')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">20분</button>
                                    <button type="button" onclick="selectTimeMinute('30')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">30분</button>
                                    <button type="button" onclick="selectTimeMinute('40')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">40분</button>
                                    <button type="button" onclick="selectTimeMinute('50')" class="time-minute-btn px-2 py-1.5 text-sm border border-gray-300 rounded hover:bg-green-50">50분</button>
                                </div>
                                <button type="button" onclick="toggleCustomTimeInput()" class="w-full mt-2 px-3 py-2 text-sm bg-gray-100 border border-gray-300 rounded-lg hover:bg-gray-200">
                                    <i class="fas fa-keyboard mr-2"></i>직접 입력
                                </button>
                                <div id="customTimeInput" class="hidden mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                    <div class="flex items-center gap-2 mb-2">
                                        <input type="number" id="customHour" min="1" max="12" placeholder="시" class="w-20 px-2 py-1 text-sm border border-gray-300 rounded text-center">
                                        <span class="text-sm font-bold">시</span>
                                        <input type="number" id="customMinute" min="0" max="59" placeholder="분" class="w-20 px-2 py-1 text-sm border border-gray-300 rounded text-center">
                                        <span class="text-sm font-bold">분</span>
                                        <button type="button" onclick="applyCustomTime()" class="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">
                                            확인
                                        </button>
                                    </div>
                                    <p class="text-xs text-gray-600">※ 오전/오후를 먼저 선택한 후 시간을 입력하세요</p>
                                </div>
                                <input type="text" id="installTime" readonly
                                       class="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg bg-gray-50 text-center font-semibold"
                                       placeholder="시간을 선택하세요">
                            </div>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-bold text-gray-700 mb-2">
                                <i class="fas fa-map-marker-alt mr-2"></i>설치 주소
                            </label>
                            <div class="flex gap-2">
                                <input type="text" id="installAddress" 
                                       class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                       placeholder="설치 장소 주소를 입력하세요">
                                <button onclick="copyCustomerAddress()" type="button"
                                        class="px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 whitespace-nowrap">
                                    <i class="fas fa-copy mr-2"></i>고객 주소 복사
                                </button>
                            </div>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-bold text-gray-700 mb-2">
                                <i class="fas fa-comment mr-2"></i>특이사항 / 비고
                            </label>
                            <textarea id="notes" rows="4"
                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                      placeholder="설치 시 주의사항이나 특이사항을 입력하세요"></textarea>
                        </div>
                    </div>
                    <div class="mt-6 flex justify-end space-x-4">
                        <button onclick="prevStep(2)" 
                                class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-arrow-left mr-2"></i>이전
                        </button>
                        <button onclick="nextStep(4)" 
                                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                            다음 <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </div>

                <!-- Step 4: 최종 확인 및 발송 -->
                <div id="confirm-section" class="bg-white rounded-lg shadow-lg p-8 mb-8 hidden">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800">
                        <i class="fas fa-check-double text-blue-600 mr-2"></i>
                        4단계: 최종 확인 및 발송
                    </h2>
                    <div id="finalPreview" class="mb-6"></div>
                    <div class="flex justify-end space-x-4">
                        <button onclick="prevStep(3)" 
                                class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-arrow-left mr-2"></i>이전
                        </button>
                        <button onclick="saveReport()" 
                                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-save mr-2"></i>저장하기
                        </button>
                        <button onclick="sendEmail()" 
                                class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700">
                            <i class="fas fa-envelope mr-2"></i>이메일 발송
                        </button>
                        <button onclick="nextStep(5)" 
                                class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700">
                            저장 문서 관리 <i class="fas fa-arrow-right ml-2"></i>
                        </button>
                    </div>
                </div>

                <!-- Step 5: 저장 문서 관리 -->
                <div id="manage-section" class="bg-white rounded-lg shadow-lg p-8 mb-8 hidden">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800">
                        <i class="fas fa-folder-open text-purple-600 mr-2"></i>
                        5단계: 저장 문서 관리
                    </h2>
                    
                    <!-- 검색 및 필터 -->
                    <div class="mb-6">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-calendar mr-2"></i>시작 날짜
                                </label>
                                <input type="date" id="searchStartDate" 
                                       onchange="searchReports()"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-calendar mr-2"></i>종료 날짜
                                </label>
                                <input type="date" id="searchEndDate" 
                                       onchange="searchReports()"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">
                                    <i class="fas fa-search mr-2"></i>고객명 검색
                                </label>
                                <input type="text" id="searchCustomerName" 
                                       placeholder="고객명 입력..."
                                       oninput="searchReports()"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            </div>
                        </div>
                        <div class="mt-4 flex justify-between items-center">
                            <div class="flex gap-2">
                                <button onclick="searchReports()" 
                                        class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700">
                                    <i class="fas fa-search mr-2"></i>검색
                                </button>
                                <button onclick="resetSearch()" 
                                        class="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600">
                                    <i class="fas fa-redo mr-2"></i>초기화
                                </button>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="exportToExcel()" 
                                        class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                                    <i class="fas fa-file-excel mr-2"></i>Excel 내보내기
                                </button>
                                <button onclick="document.getElementById('excelFileInput').click()" 
                                        class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                                    <i class="fas fa-upload mr-2"></i>데이터 가져오기
                                </button>
                                <button onclick="confirmDataReset()" 
                                        class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">
                                    <i class="fas fa-trash mr-2"></i>데이터 초기화
                                </button>
                            </div>
                        </div>
                        
                        <!-- 숨겨진 Excel 파일 입력 -->
                        <input type="file" id="excelFileInput" accept=".xlsx,.xls" style="display:none;" onchange="importFromExcel(event)" />
                    </div>
                    
                    <!-- 문서 목록 -->
                    <div id="reportsList" class="space-y-4">
                        <div class="text-center py-12 text-gray-500">
                            <i class="fas fa-folder-open text-6xl mb-4"></i>
                            <p>저장된 문서가 없습니다.</p>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-start">
                        <button onclick="prevStep(4)" 
                                class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-arrow-left mr-2"></i>이전
                        </button>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <footer class="bg-gray-800 text-white py-6 mt-12">
                <div class="container mx-auto px-4">
                    <div class="flex items-center justify-center gap-4">
                        <img src="/static/kvan-logo.png" alt="K-VAN" class="h-8 w-auto bg-white px-2 py-1 rounded">
                        <p>&copy; 2026 K-VAN PV5 시공관리 시스템. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
        <script src="/static/app.js"><\/script>
    </body>
    </html>
  `));const tt=new Pt,Or=Object.assign({"/src/index.tsx":_});let Nt=!1;for(const[,e]of Object.entries(Or))e&&(tt.all("*",t=>{let r;try{r=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,r)}),tt.notFound(t=>{let r;try{r=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,r)}),Nt=!0);if(!Nt)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{tt as default};
